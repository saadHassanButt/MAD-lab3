import 'package:flutter/material.dart';
import 'dart:ui'; // For Offset, Rect
import 'package:flutter/services.dart'; // For TextSelection
import 'package:flutter/widgets.dart'; // For TextDirection
import 'package:flutter/semantics.dart'; // For SemanticsAction

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
      ),
      home: const MyHomePage(title: 'Introduction App'),
    );
  }
}

class MyHomePage extends StatelessWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white, // Background color set to white
      appBar: AppBar(
        backgroundColor: Colors.blueAccent, // App bar color set to blue accent
        title: const Text(
          'Introduction App',
          style: TextStyle(color: Colors.white), // Title color set to white
        ),
      ),
      body: const Center(
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              
              SizedBox(height: 10),
              Text.rich(
                TextSpan(
                  children: [
                      
      TextSpan(text: '  '), // Space between star and text
      TextSpan(
        text: 'My Name: ',
        style: TextStyle(fontWeight: FontWeight.bold), // Bold name
      ),
      TextSpan(text: 'Saad Hassan Butt\n\n'),
      TextSpan(
        text: 'Qualities: ',
        style: TextStyle(fontStyle: FontStyle.italic), // Italic qualities
      ),
      TextSpan(text: 'Hardworking, Passionate, Dedicated\n\n'),
      WidgetSpan(
                        child: Icon(Icons.star, size: 20, color: Colors.amber),
                      ),
      TextSpan(
        text:
            'I am a BSCS student who is lost in his life. '
            'and is looking for his purpose on this world. '
            'he used to love coding but now he just wants to travel.',
      ),
    ],
  ),
  textAlign: TextAlign.center,
  style: TextStyle(fontSize: 16),
),
            ],
          ),
        ),
      ),
    );
  }
}
